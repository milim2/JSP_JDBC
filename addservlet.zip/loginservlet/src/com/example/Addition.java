package com.example;

public class Addition {
	public int sum(int leftOp, int rightOp) {
		return leftOp + rightOp;
	}
}
