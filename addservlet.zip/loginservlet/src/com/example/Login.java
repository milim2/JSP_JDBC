package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String leftOp = req.getParameter("leftoperand");
		String rightOp = req.getParameter("rightoperand");
		
		//Convert String to int primitive
		int leftOpInt = Integer.parseInt(leftOp);
		int rightOpInt = Integer.parseInt(rightOp);
		
		int result = leftOpInt + rightOpInt;
		
;		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		out.println("<h1>Milim Lee 991274533</h1>");

		if(username.equals("Sheridan") && 
				password.equals("Sheridan")) {
			out.println("Login success !!!!");
			out.println("Arithmetic Result = " + result);
		} else {
			out.println("Login FAILED !!!!");
		}
		
		out.close();
			
	}


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doPost(req, resp);
	}

}
