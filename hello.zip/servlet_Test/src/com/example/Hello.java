package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Hello extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");

		resp.getWriter().append("<h1>Hello World Servlet!</h1>")

		.append("<html> " + "<body>" + "<h1>Welcome to Java 3 Servlet</h1>" + "<br>"
				+ "<h2><i>Sheridan College - Davis Campus" + "</br>" + "<br>" + "7899 Mclaughlin Road" + "</br>"
				+ "<br>" + "7Brampton, Ontario" + "</br>" + "<br>" + "L6Y 5H9" + "</br>" + "</br></i></h2></body>"
				+ "</html>");
		out.close();
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		Date today = new Date();
		resp.getWriter().append("<html> " + "<body>" + "<h1>Welcome to Java 3 Servlet</h1>" + "<br>"
				+ "<h2>Milim lee</h2>" + "</br>" + "<br>" + today + "</br></body>" + "</html>");
		out.close();
	}
	}


