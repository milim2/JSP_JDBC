package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Registration extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doPost(req, resp);

		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");

		String fname = req.getParameter("fname");
		String lname = req.getParameter("lname");
		String address = req.getParameter("address");
		String prov = req.getParameter("prov");
		String country = req.getParameter("country");
		String pcode = req.getParameter("pcode");

		out.print("<h2><p style=\"color:black\">Milim Lee 991274533</p><h2>");

		if (fname.isEmpty() || lname.isEmpty() || address.isEmpty() || prov.isEmpty() || prov.isEmpty()
				|| country.isEmpty() || pcode.isEmpty()) {

			out.println("<h2><p style=\"color:red\">*** Please fill all of the fields !!</p></h2>");
			RequestDispatcher rd = req.getRequestDispatcher("register.jsp");
			rd.include(req, resp);

		} else {

			out.println("<h2><style=\"color:green\">Contratulations you are now Registered !!!</h2>");
			out.println("First Name : " + fname + "<br>");
			out.println("Last Name  : " + lname + "<br>");
			out.println("Address    : " + address + "<br>");
			out.println("Province   : " + prov + "<br>");
			out.println("Country    : " + country + "<br>");
			out.println("Postal Code: " + pcode + "<br>");
			
			out.println("<h3><p style=\"color:green\">"
					+ "<a href=\"welcome.jsp\">Click here to goto the Log in page!!!</a></p></h3>");
		}

		out.close();
	}

}
