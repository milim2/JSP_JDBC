package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Welcome extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {

		String name = req.getParameter("user");
		String pass = req.getParameter("password");

		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");

		// The color attribute of <font> is not supported in HTML5. Use CSS instead.
		out.print("<h2><p style=\"color:black\">Milim Lee 991274533</p><h2>");

		if (name.equals("Sheridan") && pass.equals("Sheridan")) {
			
//			out.println("<h2><p style=\"color:green\">Congratulations you are logged in !!!</p></h2>");
			
			RequestDispatcher rd = req.getRequestDispatcher("ValidUser");
			rd.forward(req, resp);
		
		} else {
			out.println("<h2><p style=\"color:red\">Please register and contact IT !!!</p></h2>");
			// Please Login Here <a href='index.jsp'>Go to Login</a>
			out.println("<a href=\"register.jsp\">Click here to goto the Registration page!!!</a>");
		}

		out.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doPost(req, resp);
	}

}
