package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ValidUser extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doGet(req, resp);
		PrintWriter out = resp.getWriter();
		
		
		out.println("<h2><p style=\"color:#45a049\">Congratulations you are LOGGED IN !!!</p></h2>");
        out.println("<p><a class=\"vglnk\" "
                + "href=\"http://javawebtutor.com\" "
                + "rel=\"nofollow\"><br>"
                + "<span>More Web APP Programming</span>"
                + "<span>.</span>"
                + "<span>com</span></a></p>");
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doPost(req, resp);
	}

}
